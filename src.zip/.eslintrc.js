module.exports = {
  extends: ["react-app", "react-app/jest"],
  rules: {
    "jsx-a11y/anchor-is-valid": "off"
  }
};
